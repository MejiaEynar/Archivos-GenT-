import React, { useEffect, useState } from 'react';

function App() {
  const [people, setPeople] = useState([]);
  const [selectedUrl, setSelectedUrl] = useState('');
  const [character, setCharacter] = useState(null);
  const [nickname, setNickname] = useState('');
  const [favorite, setFavorite] = useState(false);
  const [savedFicha, setSavedFicha] = useState(null);
  const [loading, setLoading] = useState(false);

  // Fetch personajes al montar
  useEffect(() => {
    fetch('https://swapi.dev/api/people/?page=1')
      .then(res => res.json())
      .then(data => setPeople(data.results));
  }, []);

  // Fetch personaje seleccionado
  useEffect(() => {
    if (!selectedUrl) return;
    setLoading(true);
    fetch(selectedUrl)
      .then(res => res.json())
      .then(data => {
        setCharacter(data);
        setLoading(false);
      });
  }, [selectedUrl]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (nickname.length < 2) {
      alert('El apodo debe tener al menos 2 caracteres');
      return;
    }
    setSavedFicha({
      ...character,
      nickname,
      favorite
    });
    localStorage.setItem("ficha", JSON.stringify({
      ...character,
      nickname,
      favorite
    }));
  };

  useEffect(() => {
    const storedFicha = localStorage.getItem("ficha");
    if (storedFicha) {
      setSavedFicha(JSON.parse(storedFicha));
    }
  }, []);

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      <h1>Ficha Galáctica</h1>

      <label>Selecciona un personaje: </label>
      <select onChange={(e) => setSelectedUrl(e.target.value)}>
        <option value="">-- Elegir --</option>
        {people.map(p => (
          <option key={p.name} value={p.url}>{p.name}</option>
        ))}
      </select>

      {loading && <p>Cargando...</p>}

      {character && (
        <div style={{ marginTop: '20px' }}>
          <h2>Vista previa</h2>
          <p><b>Nombre:</b> {character.name}</p>
          <p><b>Altura:</b> {character.height} cm</p>
          <p><b>Nacimiento:</b> {character.birth_year}</p>

          <form onSubmit={handleSubmit} style={{ marginTop: '15px' }}>
            <label>
              Apodo en tu ficha:{" "}
              <input 
                type="text" 
                value={nickname} 
                onChange={(e) => setNickname(e.target.value)} 
              />
            </label>
            <br />
            <label>
              ¿Es tu favorito?{" "}
              <input 
                type="checkbox" 
                checked={favorite} 
                onChange={(e) => setFavorite(e.target.checked)} 
              />
            </label>
            <br />
            <button type="submit">Guardar ficha</button>
          </form>
        </div>
      )}

      {savedFicha && (
        <div style={{ marginTop: '30px', padding: '15px', border: '1px solid black' }}>
          <h2>Ficha Guardada</h2>
          <p><b>Nombre:</b> {savedFicha.name}</p>
          <p><b>Apodo:</b> {savedFicha.nickname}</p>
          <p><b>Altura:</b> {savedFicha.height} cm</p>
          <p><b>Nacimiento:</b> {savedFicha.birth_year}</p>
          <p><b>Favorito:</b> {savedFicha.favorite ? 'Sí' : 'No'}</p>
        </div>
      )}
    </div>
  );
}

export default App;
