import React, { useState } from 'react';
import 'semantic-ui-css/semantic.min.css';
import CharacterList from './CharacterList';
import CharacterDetail from './CharacterDetail';
import { Button } from 'semantic-ui-react';

function App() {
  const [selectedCharacter, setSelectedCharacter] = useState(null);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Rick and Morty App</h1>
      {selectedCharacter ? (
        <div>
          <Button onClick={() => setSelectedCharacter(null)}>Volver</Button>
          <CharacterDetail character={selectedCharacter} />
        </div>
      ) : (
        <CharacterList onSelectCharacter={setSelectedCharacter} />
      )}
    </div>
  );
}

export default App;
