import React, { useEffect, useState } from 'react';
import { Card, Grid, Image } from 'semantic-ui-react';

function CharacterList({ onSelectCharacter }) {
  const [characters, setCharacters] = useState([]);

  useEffect(() => {
    fetch('https://rickandmortyapi.com/api/character')
      .then(res => res.json())
      .then(data => setCharacters(data.results));
  }, []);

  return (
    <Grid columns={4} doubling stackable>
      {characters.map(char => (
        <Grid.Column key={char.id} style={{ marginBottom: '20px' }}>
          <Card onClick={() => onSelectCharacter(char)}>
            <Image src={char.image} wrapped ui={false} />
            <Card.Content>
              <Card.Header>{char.name}</Card.Header>
              <Card.Meta>{char.species}</Card.Meta>
            </Card.Content>
          </Card>
        </Grid.Column>
      ))}
    </Grid>
  );
}

export default CharacterList;
