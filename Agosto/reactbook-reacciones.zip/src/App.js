import React, { useState } from 'react';
import './App.css';

function App() {
  const [likes, setLikes] = useState(0);
  const [funnys, setFunnys] = useState(0);
  const [surprises, setSurprises] = useState(0);
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState([]);
  const [error, setError] = useState('');

  const handleComment = () => {
    if (comment.trim() === '' || comment.length > 40) {
      setError('El comentario debe tener entre 1 y 40 caracteres.');
      return;
    }
    setComments([...comments, comment]);
    setComment('');
    setError('');
  };

  return (
    <div className="post">
      <img 
        src="https://i.imgflip.com/30b1gx.jpg" 
        alt="meme" 
        className="post-img" 
      />
      <p className="post-text">¡Mi primer post en Reactbook!</p>
      
      <div className="reactions">
        <button onClick={() => setLikes(likes + 1)}>❤ {likes}</button>
        <button onClick={() => setFunnys(funnys + 1)}>😂 {funnys}</button>
        <button onClick={() => setSurprises(surprises + 1)}>😲 {surprises}</button>
      </div>

      <div className="comment-section">
        <input 
          type="text" 
          value={comment} 
          maxLength="40"
          onChange={(e) => setComment(e.target.value)} 
          placeholder="Escribe un comentario..." 
        />
        <button onClick={handleComment}>Comentar</button>
        {error && <p className="error">{error}</p>}
      </div>

      <div className="comments-list">
        {comments.map((c, i) => (
          <p key={i} className="comment">{c}</p>
        ))}
      </div>
    </div>
  );
}

export default App;
