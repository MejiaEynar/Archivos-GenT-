-- Inserción de 5 registros
INSERT INTO Mascotas (nombre, tipo, edad, fecha_ingreso)
VALUES ('Firulais', 'Perro', 3, '2023-01-10');

INSERT INTO Mascotas (nombre, tipo, edad, fecha_ingreso)
VALUES ('Michi', 'Gato', 2, '2023-02-15');

INSERT INTO Mascotas (nombre, tipo, edad, fecha_ingreso)
VALUES ('Kira', 'Conejo', 1, '2023-03-20');

INSERT INTO Mascotas (nombre, tipo, edad, fecha_ingreso)
VALUES ('Loki', 'Perro', 5, '2022-11-05');

INSERT INTO Mascotas (nombre, tipo, edad, fecha_ingreso)
VALUES ('Nemo', 'Pez', 1, '2023-04-01');
