# Tarea de Clase 22 - Base de Datos

Este proyecto contiene la creación de una tabla `Mascotas` con sus inserciones y consultas básicas.

## Contenido
- `schema.sql`: Definición de la tabla con clave primaria y tipos de datos.
- `insert.sql`: Inserción de 5 registros de ejemplo.
- `queries.sql`: Consultas de práctica (SELECT con WHERE y ORDER BY).

## Uso
Puedes ejecutar los scripts en tu base de datos PostgreSQL o MySQL con:

```bash
psql -U usuario -d basedatos -f schema.sql
psql -U usuario -d basedatos -f insert.sql
psql -U usuario -d basedatos -f queries.sql
```

O si usas MySQL:

```bash
mysql -u usuario -p basedatos < schema.sql
mysql -u usuario -p basedatos < insert.sql
mysql -u usuario -p basedatos < queries.sql
```
