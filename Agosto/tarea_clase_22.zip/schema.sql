-- Creación de la tabla Mascotas
CREATE TABLE Mascotas (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo VARCHAR(30) NOT NULL,
    edad INTEGER,
    fecha_ingreso DATE
);
