-- Consultas básicas

-- Mostrar todos los registros
SELECT * FROM Mascotas;

-- Filtrar por tipo
SELECT * FROM Mascotas WHERE tipo = 'Perro';

-- Ordenar por edad descendente
SELECT * FROM Mascotas ORDER BY edad DESC;
